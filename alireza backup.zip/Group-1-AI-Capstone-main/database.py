# database.py
import psycopg2
from psycopg2 import sql

class DatabaseManager:
    def __init__(self):
        self.db_config = {
            "dbname": "postgres",
            "user": "team1",
            "password": "mypassword",
            "host": "localhost",
            "port": "5432"
        }
        self.create_table()

    def connect_db(self):
        return psycopg2.connect(**self.db_config)

    def get_all_meals(self):
        """
        Fetch all meals from the meal_plans table.
        """
        query = "SELECT id, meal_plan FROM meal_plans"
        try:
            with self.connect_db() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(query)
                    meals = cursor.fetchall()
                    # Return a list of dictionaries with 'id' and 'name'
                    return [{"id": meal[0], "name": meal[1]} for meal in meals]
        except Exception as e:
            print(f"Error fetching meals: {e}")
            return []

    def create_table(self):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                # Create table for meal plans
                cursor.execute(""" 
                CREATE TABLE IF NOT EXISTS meal_plans (
                    id SERIAL PRIMARY KEY,
                    food_available TEXT,
                    food_preference TEXT,
                    allergies TEXT,
                    weight TEXT,
                    height TEXT,
                    age TEXT,
                    number_of_people INTEGER,
                    sex TEXT,
                    fitness_goal TEXT,
                    meal_plan TEXT
                );
                """)
                
                # Create table for generated recipes
                cursor.execute(""" 
                CREATE TABLE IF NOT EXISTS recipe_generated (
                    id SERIAL PRIMARY KEY,
                    ingredients TEXT,
                    number_of_servings INTEGER,
                    food_preferences TEXT,
                    allergies TEXT,
                    special_requests TEXT,
                    recipe TEXT
                );
                """)
                
                # Create table for favorite recipes with name
                cursor.execute(""" 
                CREATE TABLE IF NOT EXISTS favorite_recipes (
                    id SERIAL PRIMARY KEY,
                    name TEXT,  
                    recipe TEXT
                );
                """)
                conn.commit()

    def save_meal_plan(self, food_available, food_preference, allergies, weight, height, 
                      age, number_of_people, sex, fitness_goal, meal_plan):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute(""" 
                INSERT INTO meal_plans (food_available, food_preference, allergies, weight, 
                                     height, age, number_of_people, sex, fitness_goal, meal_plan)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                """, (food_available, food_preference, allergies, weight, height, 
                     age, number_of_people, sex, fitness_goal, meal_plan))
                conn.commit()

    def save_generated_recipe(self, ingredients, number_of_servings, food_preferences, 
                            allergies, special_requests, recipe):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute(""" 
                INSERT INTO recipe_generated (ingredients, number_of_servings, food_preferences, 
                                           allergies, special_requests, recipe)
                VALUES (%s, %s, %s, %s, %s, %s);
                """, (ingredients, number_of_servings, food_preferences, allergies, 
                     special_requests, recipe))
                conn.commit()

    def save_recipe(self, name, recipe):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute(""" 
                INSERT INTO favorite_recipes (name, recipe)
                VALUES (%s, %s);
                """, (name, recipe))
                conn.commit()

    def get_favorite_recipes(self):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM favorite_recipes;")
                return cursor.fetchall()

    def get_recipes(self):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM recipe_generated;")
                return cursor.fetchall()

    def get_meal_plans(self):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM meal_plans;")
                return cursor.fetchall()

    def delete_meal_plan(self, meal_plan_id):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM meal_plans WHERE id = %s;", (meal_plan_id,))
                conn.commit()

    def delete_favorite_recipe_from_db(self, recipe_id):
        with self.connect_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM favorite_recipes WHERE id = %s;", (recipe_id,))
                conn.commit()