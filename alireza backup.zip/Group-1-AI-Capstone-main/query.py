# query.py
import random

class QueryManager:
    def construct_meal_plan_query(self, food_available, food_preference, allergies, 
                                weight, height, age, number_of_people, sex, fitness_goal):
        meal_suffix = f" for {number_of_people} people"
        
        query = (
            f"The available food includes: {food_available}.\n"
            f"Only serve available food; if you don't have, tell them.\n"
            f"I prefer {food_preference} food.\n"
            f"I have allergies to {allergies}.\n"
        )

        if weight is not None:
            query += f"My weight is {weight} kg.\n"
        if height is not None:
            query += f"My height is {height} cm.\n"
        if age is not None:
            query += f"I am {age} years old.\n"

        query += (
            f"I have {number_of_people} people to feed.\n"
            f"My sex is {sex}.\n"
            f"My fitness goal is {fitness_goal}.\n"
            "I always want this on this output to show weight, height inputed, and show bmi amount. "
            "calculate BMI per person using weight and height. The input from the user will be "
            "seperated by comma. for example weight is 88, 87, 86 or height is 5'6, 5'7, or 5,8\n"
            
            "Please create a 7-day meal plan with specific meals formatted like:\n"
            "Day 1:\n\n"
            f"Breakfast (# calories):** Example meal description{meal_suffix}.\n"
            f"Lunch (# calories):** Example meal description{meal_suffix}.\n"
            f"Dinner (# calories):** Example meal description{meal_suffix}.\n"
            f"Snacks (# calories):** Example snack description{meal_suffix}.\n"
            
            "**Important Tips:\n"
            "Portion control is key: Use measuring cups and spoons to ensure you're staying within your calorie goals.\n"
            "Choose lean protein: Include lean protein sources like chicken breast, tofu, fish, and lean beef.\n"
            "Prioritize vegetables: Load up on vegetables for fiber and nutrients.\n"
            "Choose whole grains: Opt for whole-wheat pasta, brown rice, and quinoa for sustained energy and fiber.\n"
            "Stay hydrated: Drink plenty of water throughout the day.\n"
            "Be mindful of cheese: Parmesan cheese can be high in calories. Use it in moderation.\n"
            "Use olive oil sparingly: Olive oil is a healthy fat, but it's still high in calories. Use it in moderation.\n"
            
            "Remember: This is just a starting point. You can adjust the meal plan to suit your preferences and needs. "
            "Don't hesitate to experiment with different recipes and flavors to make it enjoyable.\n"
            "Remember: A registered dietitian can provide more customized guidance, taking into account your individual needs and health status."
        )
        return query

    def construct_recipe(self, ingredients, number_of_servings, food_preferences, allergies, special_requests):
        query = (
            f"### Recipe Request\n\n"
            f"Only make 1 recipe\n\n"
            f"Only make 1 course\n\n"
            f"I have the following ingredients available: **{ingredients}**.\n\n"
            f"The recipe is good for amount of {number_of_servings} people\n"
            f"I prefer **{food_preferences}** cuisine.\n\n"
            f"I am allergic to: **{allergies}**. Please ensure these are not included in the recipe.\n\n"
            f"Special requests: **{special_requests}**. \n\n"
            f"Based on the above information, please create a **3-course recipe** that is easy to follow:\n\n"
            f"**Recipe Name:**\n\n"
            f"**Cooking Time:** Approximately 1 hour\n\n"
            
            f"### Important Tips:\n"
            f"- **Portion Control:** Use measuring cups and spoons to ensure accuracy in your servings.\n"
            f"- **Adjust to Taste:** This is a starting point! Feel free to modify the recipe to suit your taste preferences.\n"
            f"- **Experiment:** Don't hesitate to try different flavors and ingredients to make the dish enjoyable.\n"
            f"- **Consult a Professional:** A registered dietitian can offer tailored advice based on your health needs and goals.\n"
            
            f"Thank you for considering my dietary needs. I look forward to your creative recipe!"
        )
        
        return query
    def generate_random_form_data(self):
        """Generate random form data for meal plan generation"""
        
        # Define possible values for each field
        fitness_goals = [
            "Weight Loss",
            "Muscle Gain",
            "Maintenance",
            "General Health",
            "Athletic Performance"
        ]
        
        food_preferences = [
            "Vegetarian",
            "Vegan",
            "Mediterranean",
            "Asian",
            "Italian",
            "Mexican",
            "Indian",
            "American"
        ]
        
        allergies_list = [
            "None",
            "Peanuts",
            "Tree Nuts",
            "Dairy",
            "Eggs",
            "Soy",
            "Wheat",
            "Shellfish"
        ]
        
        common_foods = [
            "Rice, Pasta, Bread",
            "Chicken, Beef, Fish",
            "Eggs, Milk, Cheese",
            "Tomatoes, Onions, Garlic",
            "Potatoes, Carrots, Broccoli",
            "Apples, Bananas, Oranges",
            "Olive Oil, Butter",
            "Salt, Pepper, Common Spices"
        ]
        
        # Generate random values
        random_data = {
            "fitness_goal": random.choice(fitness_goals),
            "food_preference": random.choice(food_preferences),
            "allergies": random.choice(allergies_list),
            "weight": str(random.randint(45, 120)),  # kg
            "height": str(random.randint(150, 200)),  # cm
            "age": str(random.randint(18, 70)),
            "number_of_people": random.randint(1, 6),
            "sex": random.choice(["Male", "Female", "Other"]),
            "food_available": ", ".join(random.sample(common_foods, k=random.randint(3, 6)))
        }
        
        return random_data
    def construct_nutrient_and_calorie_query(self, bmi, meal_details, calories, nutrients, goals, self_reference=None):
        """
        Constructs a query for nutrient and calorie tracking.
        
        Args:
            bmi (str): User's BMI
            meal_details (str): Details about the meals
            calories (str): Calorie information
            nutrients (str): Nutrient information
            goals (str): User's health/fitness goals
            self_reference (optional): Reference to self, can be ignored
            
        Returns:
            str: Formatted query for the AI model
        """
        query = (
            f"### Nutrient and Calorie Analysis\n\n"
            f"BMI: {bmi}\n"
            f"Meal Details: {meal_details}\n"
            f"Calories Consumed: {calories}\n"
            f"Nutrients Consumed: {nutrients}\n"
            f"Health Goals: {goals}\n\n"
            
            "Please provide a detailed analysis including:\n"
            "1. Current caloric intake versus recommended intake based on BMI\n"
            "2. Nutrient balance analysis\n"
            "3. Suggestions for improvement\n"
            "4. Alignment with stated health goals\n"
            "5. Specific recommendations for adjusting meal choices\n\n"
            
            "Please format the response with clear sections and bullet points where appropriate.\n"
            "Include specific, actionable recommendations that align with the stated health goals."
        )
        
        return query