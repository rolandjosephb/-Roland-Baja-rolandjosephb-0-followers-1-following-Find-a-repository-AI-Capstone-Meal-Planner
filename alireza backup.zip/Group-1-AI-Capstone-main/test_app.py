import os
import pytest
from unittest.mock import patch, MagicMock

os.environ['GEMINI_API_KEY'] = 'test_api_key'


# Fixture for client with patched dependencies
@pytest.fixture
def client():
    """Fixture to initialize the Flask test client with mocked dependencies."""
    with patch('database.DatabaseManager', autospec=True) as mock_db_manager, \
            patch('query.QueryManager', autospec=True) as mock_query_manager:
        from app import MealPlanApp

        # Mock dependencies
        mock_db = mock_db_manager.return_value
        mock_query = mock_query_manager.return_value

        # Initialize the app
        flask_app = MealPlanApp()
        app = flask_app.app

        # Inject mocks
        flask_app.db = mock_db
        flask_app.query_builder = mock_query

        with app.test_client() as test_client:
            yield test_client, mock_db, mock_query


def test_index(client):
    """Test the index page loads correctly."""
    test_client, _, _ = client
    response = test_client.get('/')
    assert response.status_code == 200
    assert b"<title>Meal Planner</title>" in response.data


@patch('google.generativeai.GenerativeModel.start_chat')
def test_generate_meal_plan(mock_start_chat, client):
    """Test the meal plan generation route."""
    test_client, mock_db, mock_query = client

    # Mock the query and response
    mock_query.construct_meal_plan_query.return_value = "Generated Query"
    mock_start_chat.return_value.send_message.return_value.text = "Sample Meal Plan"

    response = test_client.post('/generate_meal_plan', json={
        "food_available": "rice",
        "food_preference": "vegetarian",
        "allergies": ["peanut"],
        "weight": "70",
        "height": "175",
        "age": "30",
        "number_of_people": 2,
        "sex": "male",
        "fitness_goal": "weight loss"
    })

    assert response.status_code == 200
    assert response.json["meal_plan"] == "Sample Meal Plan"
    mock_db.save_meal_plan.assert_called_once()


def test_autogenerate_form(client):
    """Test the autogenerate form route."""
    test_client, _, mock_query = client
    mock_query.generate_random_form_data.return_value = {"sample_key": "sample_value"}

    response = test_client.get('/autogenerate_form')
    assert response.status_code == 200
    assert response.json == {"sample_key": "sample_value"}


def test_view_meal_plans(client):
    """Test the meal plan history page."""
    test_client, mock_db, _ = client

    # Mock data
    mock_db.get_meal_plans.return_value = [
        (1, "rice", "vegetarian", "peanut", "70", "175", "30", 2, "male", "weight loss", "Sample Meal Plan Content")
    ]

    response = test_client.get('/view_meal_plans')
    assert response.status_code == 200
    assert b"Sample Meal Plan Content" in response.data
    assert b"rice" in response.data
    assert b"Delete" in response.data


def test_delete_meal_plan_route(client):
    """Test deleting a meal plan."""
    test_client, mock_db, _ = client

    response = test_client.post('/delete_meal_plan/1')
    assert response.status_code == 302  # Redirect
    mock_db.delete_meal_plan.assert_called_once_with(1)


def test_recipe_generator(client):
    """Test the recipe generator page loads."""
    test_client, _, _ = client

    response = test_client.get('/recipe_generator')
    assert response.status_code == 200
    assert b"<title>Recipe Generator</title>" in response.data


@patch('google.generativeai.GenerativeModel.start_chat')
def test_generate_recipe(mock_start_chat, client):
    """Test generating a recipe."""
    test_client, mock_db, mock_query = client

    # Mock the query and response
    mock_query.construct_recipe.return_value = "Generated Recipe Query"
    mock_start_chat.return_value.send_message.return_value.text = "Sample Recipe"

    response = test_client.post('/generate_recipe', json={
        "ingredients": "tomatoes",
        "number_of_servings": 2,
        "food_preferences": "vegan",
        "allergies": ["gluten"],
        "special_requests": "low salt"
    })

    assert response.status_code == 200
    assert response.json["recipe"] == "Sample Recipe"
    mock_db.save_generated_recipe.assert_called_once()


def test_save_favorite_recipe(client):
    """Test saving a favorite recipe."""
    test_client, mock_db, _ = client

    response = test_client.post('/save_favorite_recipe', json={
        "recipe": "Sample Recipe",
        "name": "Favorite Recipe"
    })

    assert response.status_code == 200
    assert response.json["success"] is True
    mock_db.save_recipe.assert_called_once_with("Favorite Recipe", "Sample Recipe")


def test_view_favourite_recipes(client):
    """Test viewing favorite recipes."""
    test_client, mock_db, _ = client

    # Mock data
    mock_db.get_favorite_recipes.return_value = [
        (1, "Favorite Recipe", "Sample Recipe Content")
    ]

    response = test_client.get('/view_favourite_recipes')
    assert response.status_code == 200
    assert b"Favorite Recipe" in response.data
    assert b"Sample Recipe Content" in response.data
    assert b"Delete" in response.data


def test_delete_favorite_recipe(client):
    """Test deleting a favorite recipe."""
    test_client, mock_db, _ = client

    response = test_client.post('/delete_favorite_recipe/1')
    assert response.status_code == 302  # Redirect
    mock_db.delete_favorite_recipe_from_db.assert_called_once_with(1)


@patch('google.generativeai.GenerativeModel.start_chat')
def test_track_nutrient_and_calorie(mock_start_chat, client):
    """Test tracking nutrients and calories."""
    test_client, _, mock_query = client

    # Mock the query and response
    mock_query.construct_nutrient_and_calorie_query.return_value = "Generated Nutrient Query"
    mock_start_chat.return_value.send_message.return_value.text = "Sample Nutrient Info"

    response = test_client.post('/track_nutrient_and_calorie', data={
        "bmi": "22.5",
        "meal_details": "Pasta",
        "calories": "500",
        "nutrients": "Carbs",
        "goals": "Weight gain"
    })

    assert response.status_code == 200
    assert b"Sample Nutrient Info" in response.data
