import os
from flask import Flask, request, jsonify, render_template, redirect, url_for
import google.generativeai as genai
from dotenv import load_dotenv
from query import QueryManager
from database import DatabaseManager


class MealPlanApp:
    def __init__(self):
        """
        Initialize the application by loading environment variables, configuring the API,
        setting up the Flask app, and initializing database and query builder.
        """
        load_dotenv()
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        
        # Configuration for the generative AI model
        self.generation_config = {
            "temperature": 1,
            "top_p": 0.95,
            "top_k": 64,
            "max_output_tokens": 1024,
            "response_mime_type": "text/plain",
        }

        # Initialize the Generative AI model
        self.model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            generation_config=self.generation_config,
        )
        
        # Initialize Flask app and related components
        self.app = Flask(__name__)
        self.db = DatabaseManager()
        self.query_builder = QueryManager()

        # Register routes
        self._register_routes()

    def _register_routes(self):
        """
        Register all the routes for the Flask app.
        """
        @self.app.route('/')
        def index():
            """
            Render the homepage template.
            """
            return render_template('index.html')

        @self.app.route('/generate_meal_plan', methods=['POST'])
        def generate_meal_plan():
            """
            Generate a meal plan based on user input, save it to the database,
            and return the generated meal plan as a JSON response.
            """
            data = request.json
            query = self.query_builder.construct_meal_plan_query(
                data.get("food_available"),
                data.get("food_preference"),
                data.get("allergies"),
                data.get("weight"),
                data.get("height"),
                data.get("age"),
                data.get("number_of_people"),
                data.get("sex"),
                data.get("fitness_goal")
            )

            chat_session = self.model.start_chat(history=[])
            response = chat_session.send_message(query)
            formatted_response = response.text.strip()

            # Save the generated meal plan in the database
            self.db.save_meal_plan(
                data.get("food_available"),
                data.get("food_preference"),
                data.get("allergies"),
                data.get("weight"),
                data.get("height"),
                data.get("age"),
                data.get("number_of_people"),
                data.get("sex"),
                data.get("fitness_goal"),
                formatted_response
            )
            return jsonify({"meal_plan": formatted_response})

        @self.app.route('/autogenerate_form', methods=['GET'])
        def autogenerate_form():
            """
            Generate random data for a meal plan form and return it as JSON.
            """
            generated_data = self.query_builder.generate_random_form_data()
            return jsonify(generated_data)

        @self.app.route('/view_meal_plans', methods=['GET'])
        def view_meal_plans():
            """
            Fetch all meal plans from the database and render the view template.
            """
            meal_plans = self.db.get_meal_plans()
            return render_template('view_meal_plans.html', meal_plans=meal_plans)

        @self.app.route('/delete_meal_plan/<int:meal_plan_id>', methods=['POST'])
        def delete_meal_plan_route(meal_plan_id):
            """
            Delete a meal plan from the database and redirect to the meal plans view page.
            """
            self.db.delete_meal_plan(meal_plan_id)
            return redirect(url_for('view_meal_plans'))

        @self.app.route('/recipe_generator')
        def recipe_generator():
            """
            Render the recipe generator template.
            """
            return render_template('recipe_generator.html')

        @self.app.route('/generate_recipe', methods=['POST'])
        def generate_recipe():
            """
            Generate a recipe based on user input, save it to the database, and return the generated recipe as JSON.
            """
            data = request.json
            ingredients = data.get("ingredients")
            number_of_servings = data.get("number_of_servings")
            food_preferences = data.get("food_preferences")
            allergies = data.get("allergies")
            special_requests = data.get("special_requests")
            
            # Construct the query
            query = self.query_builder.construct_recipe(
                  ingredients,
                  number_of_servings,
                  food_preferences,
                  allergies,
                  special_requests
            )
            print(f"Constructed Query: {query}")  # After constructing the query
            
            # Validate the query
            if not query or query.strip() == "":
                return jsonify({"error": "Generated query is empty. Please provide valid inputs."}), 400

            # Start chat session and send message
            chat_session = self.model.start_chat(history=[])
            try:
                response = chat_session.send_message(query)
                
                if not response or not hasattr(response, 'text'):
                    print("Response from model is undefined or missing 'text' attribute.")
                    return jsonify({"error": "Failed to get a valid response from the AI model."}), 500
                
                print(f"Raw response from AI: {response}")  # Log the response for debugging
                
                # Format the response
                formatted_response = response.text.strip()

                # Save the generated recipe in the database
                self.db.save_generated_recipe(
                    data.get("ingredients"),
                    data.get("number_of_servings"),
                    data.get("food_preferences"),
                    data.get("allergies"),
                    data.get("special_requests"),
                    formatted_response
                )

                return jsonify({"recipe": formatted_response})
            except Exception as e:
                # Log the exception and return an error message
                print(f"Error during AI query: {str(e)}")
                return jsonify({"error": f"Failed to generate recipe: {str(e)}"}), 500

        @self.app.route('/save_favorite_recipe', methods=['POST'])
        def save_favorite_recipe():
            """
            Save a recipe as a favorite in the database.
            """
            data = request.get_json()
            self.db.save_recipe(data.get('name'), data.get('recipe'))
            return jsonify(success=True)

        @self.app.route('/view_favourite_recipes')
        def view_favourite_recipes():
            """
            Fetch all favorite recipes from the database and render the view template.
            """
            favorite_recipes = self.db.get_favorite_recipes()
            return render_template('view_favourite_recipe.html', favorite_recipes=favorite_recipes)

        @self.app.route('/delete_favorite_recipe/<int:recipe_id>', methods=['POST'])
        def delete_favorite_recipe(recipe_id):
            """
            Delete a favorite recipe from the database and redirect to the favorite recipes view page.
            """
            self.db.delete_favorite_recipe_from_db(recipe_id)
            return redirect(url_for('view_favourite_recipes'))

        @self.app.route('/nutrient_and_calorie')
        def nutrient_and_calorie():
            """
            Render the nutrient and calorie tracking template.
            """
            return render_template('nutrient_and_calorie.html')
        
        @self.app.route('/get_meals', methods=['GET'])
        def get_meals():
            """
            Fetch meals from the database and return them as JSON.
            """
            try:
                meals = self.db.get_all_meals()
                return jsonify(meals)
            except Exception as e:
                print(f"Error fetching meals: {e}")
                return jsonify({"error": "Failed to fetch meals"}), 500

        @self.app.route('/track_nutrient_and_calorie', methods=['POST'])
        def track_nutrient_and_calorie():
            """
            Track nutrients and calories based on user input and provide feedback.
            """
            bmi = request.form['bmi']
            meal_details = request.form['meal_details']
            calories = request.form['calories']
            nutrients = request.form['nutrients']
            goals = request.form['goals']

            query = self.query_builder.construct_nutrient_and_calorie_query(
                bmi, meal_details, calories, nutrients, goals
            )

            chat_session = self.model.start_chat(history=[])
            response = chat_session.send_message(query)
            formatted_response = response.text.strip()

            return render_template('nutrient_and_calorie.html', feedback=formatted_response)

    def run(self):
        """
        Start the Flask web application.
        """
        self.app.run(debug=True)


# Start the app
if __name__ == '__main__':
    flask_app = MealPlanApp()
    flask_app.run()
